import sys
import pygame#导入基础库
from pygame.locals import *

pygame.init()
DS = pygame.display.set_mode((1280,600))# 设定幕布
#image = pygame.image.load('img/background1.jpg')
import image
img = image.Image('img/background1.jpg', 0, (0,0),(1280,600),0)
img1 = image.Image('img/zombies/run/run_%d.png', 0, (1280,200), (100,128),30)

while True:
    for event in pygame.event.get():#死循环，保证显示
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    DS.fill((255,255,255))# 设白色
    img.draw(DS)
    img1.doLeft()
    img1.draw(DS)
    img1.updateIndex((img1.pathIndex +1)% 30)
#DS.blit(image,image.get_rect() )
    pygame.display.update()



